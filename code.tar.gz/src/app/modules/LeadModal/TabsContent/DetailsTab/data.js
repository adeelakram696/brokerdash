export const entityTypes = [
  { value: '', label: '' },
  { value: 'Sole Proprietorship', label: 'Sole Proprietorship' },
  { value: 'Corporation', label: 'Corporation' },
  { value: 'LLC', label: 'LLC' },
];
