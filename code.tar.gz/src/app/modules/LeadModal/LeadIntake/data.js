export const loanPurpose = [
  { value: 'Working Capital', label: 'Working Capital' },
  { value: 'Expansion', label: 'Expansion' },
  { value: 'Payroll', label: 'Payroll' },
  { value: 'Consolidation', label: 'Consolidation' },
  { value: 'Purchase a Business', label: 'Purchase a Business' },
  { value: 'Equipment', label: 'Equipment' },
  { value: 'Real Estate', label: 'Real Estate' },
  { value: 'Other', label: 'Other' },
];
export const importantToYou = [
  { value: 'Amount of Capital', label: 'Amount of Capital' },
  { value: 'Speed of Capital', label: 'Speed of Capital' },
  { value: 'Cost of Capital', label: 'Cost of Capital' },
];
export const monthlyRevenue = [
  { value: '$0-$19k', label: '$0-$19k' },
  { value: '$20k-$49k', label: '$20k-$49k' },
  { value: '$50k-$80k', label: '$50k-$80k' },
  { value: '$80k-$199k', label: '$80k-$199k' },
  { value: '$80-$199k', label: '$80-$199k' },
  { value: '$200k+', label: '$200k+' },
];
