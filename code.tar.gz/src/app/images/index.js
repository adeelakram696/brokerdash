export { default as approvalTick } from './approvalTick.svg';
export { default as runningShoe } from './runingShoe.svg';
export { default as signature } from './signature.svg';
